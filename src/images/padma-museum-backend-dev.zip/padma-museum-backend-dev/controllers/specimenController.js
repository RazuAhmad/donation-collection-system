const asyncHandler = require("express-async-handler");
const Specimen = require("../models/specimen");

const createSpecimen = asyncHandler(async (req, res) => {
  const product = await Specimen.create(req.body);
  res.status(200).json(product);
});

const getSpecimens = asyncHandler(async (req, res) => {
  const keyword = req.query.keyword || '';
  const limit = parseInt(req.query.limit) || 10; // default limit is 10
  const skip = parseInt(req.query.skip) || 0; // default skip is 0
  const query = {
    $or: [
      { "iDetails.regNo": { $regex: keyword, $options: 'i' } },
      { "iDetails.englishName": { $regex: keyword, $options: 'i' } },
      { "iDetails.group": { $regex: keyword, $options: 'i' } },
      { "iDetails.subGroup": { $regex: keyword, $options: 'i' } },
      { "iDetails.groupSerial": { $regex: keyword, $options: 'i' } },
      { "iDetails.habitatType": { $regex: keyword, $options: 'i' } },
      { "iDetails.category": { $regex: keyword, $options: 'i' } },
      { "iDetails.phylum": { $regex: keyword, $options: 'i' } },
      { "iDetails.class": { $regex: keyword, $options: 'i' } },
      { "iDetails.order": { $regex: keyword, $options: 'i' } },
      { "iDetails.family": { $regex: keyword, $options: 'i' } },
      { "iDetails.scientificName": { $regex: keyword, $options: 'i' } },
      { "iDetails.englishName": { $regex: keyword, $options: 'i' } },
      { "iDetails.localName": { $regex: keyword, $options: 'i' } },
      { "iDetails.referenceVP": { $regex: keyword, $options: 'i' } },
      { "iDetails.collectionPlace": { $regex: keyword, $options: 'i' } },
      { "iDetails.district": { $regex: keyword, $options: 'i' } },
      { "iDetails.collector": { $regex: keyword, $options: 'i' } },
      { "iDetails.weight": { $regex: keyword, $options: 'i' } },
      { "iDetails.age": { $regex: keyword, $options: 'i' } },
      { "iDetails.sex": { $regex: keyword, $options: 'i' } },
      { "iDetails.gpsNorth": { $regex: keyword, $options: 'i' } },
      { "iDetails.gpsEast": { $regex: keyword, $options: 'i' } },
      { "iDetails.notes": { $regex: keyword, $options: 'i' } },
      { "iDetails.reference": { $regex: keyword, $options: 'i' } },
      { "iDetails.link": { $regex: keyword, $options: 'i' } },
    ],
  };

  const totalCount = await Specimen.countDocuments(query);
  const specimens = await Specimen.find(query)
    .limit(limit)
    .skip(skip)
    .populate();

  res.status(200).json({data:specimens,totalCount});
});

const getSpecimensX = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit) || 10; // default limit is 10
  const skip = parseInt(req.query.skip) || 0; // default skip is 0
  let result=null
  if ( req.query.regNo !== 'null' && req.query.englishName !== 'null' && req.query.group !== 'null') {
    console.log('inside group')
    result = await Specimen.find({ 
      "regNo": req.query.regNo, 
      "iDetails.englishName": req.query.englishName, 
      "iDetails.group": req.query.group 
    }).limit(limit).skip(skip);
    // //res.status(200).json(specimens);
  }
  else if (req.query.group !== 'null' && req.query.regNo !== 'null') {
    console.log('inside group & regNo')
    result = await Specimen.find({ 
      "iDetails.group": req.query.group, 
      "regNo": req.query.regNo 
    }).limit(limit).skip(skip);
    //res.status(200).json(specimens);
  }
  else if (req.query.englishName !== 'null' && req.query.regNo !== 'null') {
    console.log('inside englishName & regNo')
    result = await Specimen.find({ 
      "regNo": req.query.regNo,
      "iDetails.englishName": req.query.englishName
    }).limit(limit).skip(skip);
    //res.status(200).json(specimens);
  }
  else if (req.query.englishName !== 'null' && req.query.group !== 'null') {
    console.log('inside englishName & group')
    result = await Specimen.find({ 
      "iDetails.englishName": req.query.englishName, 
      "iDetails.group": req.query.group 
    }).limit(limit).skip(skip);
    //res.status(200).json(specimens);
  }
  else if (req.query.regNo !== 'null') {
    console.log('inside regNo')
    result = await Specimen.find({ "regNo": req.query.regNo }).limit(limit).skip(skip);
    //res.status(200).json(specimens);
  }
  else if (req.query.group !== 'null') {
    console.log('inside group')
    result = await Specimen.find({ "iDetails.group": req.query.group }).limit(limit).skip(skip);
    //res.status(200).json(specimens);
  }
  
  else if (req.query.englishName !== 'null') {
    console.log('inside englishName')
    result = await Specimen.find({ "iDetails.englishName": req.query.englishName }).limit(limit).skip(skip);
    //res.status(200).json(specimens);
  }
  else {
    console.log('else');
    result = await Specimen.find().populate().limit(limit).skip(skip);
    // res.status(200).json(specimens);
  }
    res.status(200).json(result);

});



const getSpecimenById = asyncHandler(async (req, res) => {
  const specimen = await Specimen.findById(req.params.id);
  if (!specimen) {
    res.status(404);
    throw new Error("Specimen not found");
  }
  res.status(200).json(specimen);
});
const getSpecimensByIds = asyncHandler(async (req, res) => {
  const response = await Specimen.find({ _id: req.body.productIds });
  if (!product) {
    res.status(404);
    throw new Error("No products found");
  }
  res.status(200).json(response);
});

const updateSpecimen = asyncHandler(async (req, res) => {
  // console.log(req.params,req.body);
  const specimen = await Specimen.find({ _id: req.params.id });
  if (!specimen) {
    res.status(404);
    throw new Error("Specimen not found");
  }
  const updatedSpecimen = await Specimen.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
    }
  );
  res.status(200).json(updatedSpecimen);
});

const deleteMultipleSpecimens = asyncHandler(async (req, res) => {
  // console.log("Specimen deleted", req.body);
  const response = await Specimen.deleteMany({ _id: req.body.productIds });
  // const product = await Specimen.findById(req.params.id );
  // if (!product) {
  //   res.status(404);
  //   throw new Error("Specimen not found");
  // }
  // await product.remove();
  res.status(200).json(response);
});

const deleteSingleSpecimen = asyncHandler(async (req, res) => {
  const product = await Specimen.findById(req.params.id );
  if (!product) {
    res.status(404);
    throw new Error("Specimen not found");
  }
  await product.remove();
  res.status(200).json(product);
});

module.exports = {
  createSpecimen,
  getSpecimens,
  getSpecimenById,getSpecimensByIds,
  updateSpecimen,deleteSingleSpecimen,
  deleteMultipleSpecimens,
};
