const asyncHandler = require("express-async-handler");
const User = require("../models/user");
const Product = require("../models/specimen");


const getDashboardData = asyncHandler(async (req, res) => {
  const totalUsers = await User.countDocuments({role:'customer'});
  const totalProducts = await Product.countDocuments();
  const inStock = await Product.countDocuments({quantity:{$gte:1}});
  const outOfStock = await Product.countDocuments({ quantity: 0 });
  const pending = await Order.countDocuments({
    orderStatus:  "Pending" 
  });
  const accepted = await Order.countDocuments({
    orderStatus: "Accepted",
  });
  const inProgress = await Order.countDocuments({
    orderStatus: "In progress",
  });
  const delivered = await Order.countDocuments({
    orderStatus: "Delivered",
  });
  const cancelled = await Order.countDocuments({
    orderStatus: "Cancelled",
  });
  const returned = await Order.countDocuments({
    orderStatus: "Returned",
  });
  const response = {
    totalCustomers: totalUsers,
    productData: {totalProducts: totalProducts,inStock: inStock,outOfStock: outOfStock},
    // orderData: {
    //   totalOrders: totalOrders,
    //   pending: pending,
    //   accepted: accepted,
    //   inProgress: inProgress,
    //   delivered: delivered,
    //   cancelled: cancelled,
    //   returned: returned,
    // },
  };
  res.status(200).json(response);
});

module.exports = {
  getDashboardData,
};
