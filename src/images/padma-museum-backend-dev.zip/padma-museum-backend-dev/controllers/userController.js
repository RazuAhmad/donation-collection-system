const asyncHandler = require("express-async-handler");
const User = require("../models/user");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const generateToken = (id) => {
  // return jwt.sign({ id }, process.env.JWT_SECRET, {expiresIn:'30d'})
  return jwt.sign({ id }, 'abc123', {expiresIn:'30d'})
}

const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, role } = req.body;
  // console.log(req.body);
  if (!name || !email || !password || !role) {
    // return res.status(400)
    throw new Error("Please enter all fields");
  }
  const userExists = await User.findOne({ email });
  if (userExists) {
    // return res.status(400)
    throw new Error("User already exists!");
  }
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);
  const user = await User.create({
    name,
    email,
    password: hashedPassword,
    role,
  });

  if (user) {
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      access_token: generateToken(user._id),
    });
  }
  else {
    // return res.status(400)
    throw new Error("Invalid data!");
  }
});

const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  // console.log("email,password: ",req.body);
  const user = await User.findOne({ email });
  if (user && (await bcrypt.compare(password, user.password))) {
    res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id),
    });
  }
  else {
    res.status(400)
    throw new Error("Invalid data!");
  }  
});

const getMe = asyncHandler(async (req, res) => {
  // console.log(req.user)
  // const { _id, name, email,role} = await User.findById(req.user);
  
    res.status(200).json(req.user)
    // res.status(200).json({
    //   _id: _id,
    //   name,
    //   email,role
    // });
});

const getUsers = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit) || 10; // default limit is 10
  const skip = parseInt(req.query.skip) || 0; // default skip is 0
  
  const totalCount = await User.countDocuments();
  const users = await User.find()
    .limit(limit)
    .skip(skip);

  res.status(200).json({data: users, totalCount});
});

const getUserById = asyncHandler(async (req, res) => {
  // console.log("getUserById", req.params.id);
  const user = await User.find({ _id: req.params.id });
  
  const orders = await Order.find({ user: req.params.id });
  // console.log('user',user)
  if (!user) {
    res.status(404);
    throw new Error("Data not found");
  }
  const userDetails = {
    name: user[0].name,
    email: user[0].email,
    role: user[0].role,
  };
  // console.log(userDetails);
  res.status(200).json({userDetails,orders});
});

const updateUser = asyncHandler(async (req, res) => {
  const user = await User.find({ _id: req.params.id});
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }
  const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.status(200).json(updatedUser);
});

const deleteSingleUser = asyncHandler(async (req, res) => {
  const user = await User.findById({ _id: req.params.id});
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }
  await user.remove();
  res.status(200).json(user);
});

const deleteMultipleUsers = asyncHandler(async (req, res) => {
  // console.log("User deleted", req.body);
  const response = await User.deleteMany({ _id: req.body.userIds });
  // const User = await User.findById(req.params.id );
  // if (!User) {
  //   res.status(404);
  //   throw new Error("User not found");
  // }
  // await User.remove();
  res.status(200).json(response);
});

module.exports = {
  registerUser,
  loginUser,
  getMe,
  getUsers,getUserById,deleteMultipleUsers,
  updateUser,deleteSingleUser
};
