const asyncHandler = require("express-async-handler");
const SpeciesProfile = require("../models/speciesProfile");

const createSpeciesProfile = asyncHandler(async (req, res) => {
  const speciesProfile = await SpeciesProfile.create(req.body);
  res.status(200).json(speciesProfile);
});

const getSpeciesProfiles = asyncHandler(async (req, res) => {
  const keyword = req.query.keyword || '';
  const limit = parseInt(req.query.limit) || 10; // default limit is 10
  const skip = parseInt(req.query.skip) || 0; // default skip is 0
  const query = {
    $or: [
      { "englishName": { $regex: keyword, $options: 'i' } },
      { "scientificName": { $regex: keyword, $options: 'i' } }
    ],
  };

  const totalCount = await SpeciesProfile.countDocuments(query);
  const speciesProfiles = await SpeciesProfile.find(query)
    .limit(limit)
    .skip(skip)
    .populate();

  res.status(200).json({data:speciesProfiles,totalCount});
});


const getSpeciesProfileById = asyncHandler(async (req, res) => {
  const speciesProfile = await SpeciesProfile.findById(req.params.id);
  if (!speciesProfile) {
    res.status(404);
    throw new Error("SpeciesProfile not found");
  }
  res.status(200).json(speciesProfile);
});
const getSpeciesProfilesByIds = asyncHandler(async (req, res) => {
  const response = await SpeciesProfile.find({ _id: req.body.speciesProfileIds });
  if (!speciesProfile) {
    res.status(404);
    throw new Error("No speciesProfiles found");
  }
  res.status(200).json(response);
});

const updateSpeciesProfile = asyncHandler(async (req, res) => {
  // console.log(req.params,req.body);
  const speciesProfile = await SpeciesProfile.find({ _id: req.params.id });
  if (!speciesProfile) {
    res.status(404);
    throw new Error("SpeciesProfile not found");
  }
  const updatedSpeciesProfile = await SpeciesProfile.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
    }
  );
  res.status(200).json(updatedSpeciesProfile);
});

const deleteMultipleSpeciesProfiles = asyncHandler(async (req, res) => {
  const response = await SpeciesProfile.deleteMany({ _id: req.body.speciesProfileIds });
  res.status(200).json(response);
});

const deleteSingleSpeciesProfile = asyncHandler(async (req, res) => {
  const speciesProfile = await SpeciesProfile.findById(req.params.id );
  if (!speciesProfile) {
    res.status(404);
    throw new Error("SpeciesProfile not found");
  }
  await speciesProfile.remove();
  res.status(200).json(speciesProfile);
});

module.exports = {
  createSpeciesProfile,
  getSpeciesProfiles,
  getSpeciesProfileById,getSpeciesProfilesByIds,
  updateSpeciesProfile,deleteSingleSpeciesProfile,
  deleteMultipleSpeciesProfiles,
};
