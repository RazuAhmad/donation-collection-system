const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const DashboardSchema = new Schema({
  totalCustomers: {
    type: Number,
    required: true,
    default: 0,
  },
  totalProducts: {
    type: Number,
    required: true,
    default: 0,
  },
  orderData: {
    totalOrders: {
      type: Number,
      required: true,
      default: 0,
    },
    pending: {
      type: Number,
      required: true,
      default: 0,
    },
    accepted: {
      type: Number,
      required: true,
      default: 0,
    },
    inProgress: {
      type: Number,
      required: true,
      default: 0,
    },
    cancelled: {
      type: Number,
      required: true,
      default: 0,
    },
    returned: {
      type: Number,
      required: true,
      default: 0,
    },
  },
});

module.exports = mongoose.model("Dashboard", DashboardSchema);
