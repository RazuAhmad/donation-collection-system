const mongoose = require("mongoose");
const {Schema} = mongoose

const speciesProfileSchema = new Schema(
  {
    scientificName: String,
    englishName: String,
    speciesProfileLink: String
  },
  {
    timestamps: true,
  }
);


module.exports = mongoose.model("SpeciesProfile", speciesProfileSchema);
