const mongoose = require("mongoose");
const {Schema} = mongoose

const specimenSchema = new Schema(
  {
    regNo: {
      type: Number,
      required: true,
    },
    iDetails: {},
    pInfo: {},
    dataCard: {},
    catalogue: {}
  },
  {
    timestamps: true,
  }
);


module.exports = mongoose.model("Specimen", specimenSchema);
