const path = require('path');
const XLSX = require('xlsx');

function readExcelData(filename) {
  const filePath = path.join(__dirname, '../uploads', filename);
  const workbook = XLSX.readFile(filePath);
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const data = XLSX.utils.sheet_to_json(worksheet);
  return data;
}

module.exports = readExcelData;
