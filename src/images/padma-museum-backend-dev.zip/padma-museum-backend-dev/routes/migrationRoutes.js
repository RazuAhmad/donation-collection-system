const path = require('path');
const express = require('express');
const router = express.Router();
const XLSX = require('xlsx');
const readExcelData = require('../utils/parseExelData');
const Specimen = require('../models/specimen');

router.post('/update-iDetails', async (req, res) => {
  try {
    const data = readExcelData('iDetails.xlsx');
    const batchSize = 100;
    const specimens = [];

    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);

      // find existing specimens by their barcode
      const existingSpecimens = await Specimen.find({ regNo: { $in: batch.map(specimen => specimen.regNo) } });

      // update existing specimens and create new specimens for the batch
      const promises = batch.map(async (specimenData) => {
        const existingSpecimen = existingSpecimens.find(specimen => specimen.regNo === specimenData.regNo);

        if (existingSpecimen) {
          existingSpecimen.iDetails = specimenData
          await existingSpecimen.save();
          return existingSpecimen;
        } else {
          const newSpecimen = await Specimen.create({regNo:specimenData.regNo,iDetails:specimenData});
          return newSpecimen;
        }
      });

      const newSpecimens = await Promise.all(promises);
      specimens.push(...newSpecimens);

      await new Promise(resolve => setTimeout(resolve, 500)); // add a delay of 500ms between batches
    }

    res.status(200).json(specimens);
  } catch (err) {
    res.status(500).send(err.message);
  }
});
router.post('/update-catalogue', async (req, res) => {
  try {
    const data = readExcelData('catalogue.xlsx');
    const batchSize = 100;
    const specimens = [];

    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);

      // find existing specimens by their barcode
      const existingSpecimens = await Specimen.find({ regNo: { $in: batch.map(specimen => specimen.regNo) } });
      // console.log("existingSpecimens",existingSpecimens)
      // update existing specimens and create new specimens for the batch
      const promises = batch.map(async (specimenData) => {
        // console.log('specimenData',specimenData)
        const existingSpecimen = existingSpecimens.find(specimen => specimen.regNo == specimenData.regNo);

        if (existingSpecimen) {
          existingSpecimen.catalogue = specimenData
          await existingSpecimen.save();
          return existingSpecimen;
        } else {
          const newSpecimen = await Specimen.create({regNo:specimenData.regNo,catalogue:specimenData});
          return newSpecimen;
        }
      });

      const newSpecimens = await Promise.all(promises);
      specimens.push(...newSpecimens);

      await new Promise(resolve => setTimeout(resolve, 500)); // add a delay of 500ms between batches
    }

    res.status(200).json(specimens);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

module.exports = router;
