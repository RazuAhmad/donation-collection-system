
const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");

const {
  createSpeciesProfile,
  getSpeciesProfiles,
  getSpeciesProfileById,
  updateSpeciesProfile,deleteSingleSpeciesProfile,
  deleteMultipleSpeciesProfiles,
} = require("../controllers/speciesProfileController");

router.route("/remove").delete(protect, deleteMultipleSpeciesProfiles);
router.route("/").get(getSpeciesProfiles).post(createSpeciesProfile);
router.route("/:id").get(getSpeciesProfileById);
router.route("/:id").put(updateSpeciesProfile).delete(deleteSingleSpeciesProfile);


module.exports = router;