
const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");

const {
  registerUser,
  loginUser,
  getMe,
  getUsers,
  getUserById,
  deleteMultipleUsers,updateUser,deleteSingleUser
} = require("../controllers/userController");

router.get("/me", protect, getMe);
router.route("/remove").delete(protect, deleteMultipleUsers);
router.route("/:id").get(getUserById)
router.get("/", protect, getUsers);
router.route("/register").post(registerUser);
router.route("/login").post(loginUser);
router.route("/:id").put(updateUser).delete(deleteSingleUser);


module.exports = router;
