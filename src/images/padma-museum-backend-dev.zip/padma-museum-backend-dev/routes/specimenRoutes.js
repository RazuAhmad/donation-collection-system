
const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");

const {
  createSpecimen,
  getSpecimens,
  getSpecimenById,getSpecimensByIds,
  updateSpecimen,deleteSingleSpecimen,
  deleteMultipleSpecimens,
} = require("../controllers/specimenController");

router.route("/remove").delete(protect, deleteMultipleSpecimens);
router.route("/").get(getSpecimens).post(createSpecimen);
// router.route("/").get(getSpecimens).post(protect, createSpecimen);
router.route("/:id").get(getSpecimenById);
router.route("/:id").put(updateSpecimen).delete(deleteSingleSpecimen);


module.exports = router;