const userRoutes = require("./userRoutes");
const specimenRoutes = require('./specimenRoutes')
const speciesProfileRoutes = require('./speciesProfileRoutes')
const dashboardRoutes = require('./dashboardRoutes')
const uploadRoutes = require("./uploadRoutes");
const migrationRoutes = require("./migrationRoutes");

const routes = [
  {
    path: "/users",
    handler: userRoutes,
  },
  {
    path: "/specimens",
    handler: specimenRoutes,
  },
  {
    path: "/species-profiles",
    handler: speciesProfileRoutes,
  },
  {
    path: "/dashboard",
    handler: dashboardRoutes,
  },
  {
    path: "/uploads",
    handler:uploadRoutes,
  },
  {
    path: "/migrate",
    handler:migrationRoutes,
  },
];

const setRoutes = (app) => {
  routes.forEach((route) => {
    // console.log(route.path, route.handler);
    app.use(route.path, route.handler);
  });
};

module.exports = setRoutes