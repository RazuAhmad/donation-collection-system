const express = require("express");
const dotenv = require("dotenv").config;
const { errorHandler } = require("./middleware/errorMiddleware");
const port = process.env.PORT || 5000;
const setRoutes = require("./routes/routes");
const asyncHandler = require("express-async-handler");
const connectDB = require("./config/db");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
connectDB();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get(
  "/",
  asyncHandler(async (req, res) => {
    res.send("Hello from the server!");
  })
);

// const __dirname = path.resolve()
app.use('/uploads',express.static(path.join(__dirname, '/uploads')))

setRoutes(app);
app.use(errorHandler);

app.listen(port, () => console.log(`Server started on port ${port}`));
