const mongoose = require("mongoose");

const connectDB = async () => {
    try {
      // console.log(process.env.MONGO_URI);
        
      // const url = "dev";
      const url = "prod";

      const dbURL =
        url === "dev"
          ? "mongodb+srv://dbUser:Yrm1sdrmp9GZMOLK@cluster0.evhow.mongodb.net/mern-ecommerce"
          : url === "prod"
          ? "mongodb+srv://Nurnaby:2GVaREo3DdjIzP7J@cluster0.3j5km.mongodb.net/padma-museum?retryWrites=true&w=majority"
          : "mongodb+srv://Nurnaby:2GVaREo3DdjIzP7J@cluster0.3j5km.mongodb.net/padma-museum?retryWrites=true&w=majority";
        
      const connection = await mongoose.connect(
        process.env.MONGO_URI ||
          dbURL
      );
      console.log(`MongoDB Connected: ${connection.connection.host}`);
    } catch (error) {
        console.error(error.message);
        process.exit(1);
    }
}
 
module.exports = connectDB;